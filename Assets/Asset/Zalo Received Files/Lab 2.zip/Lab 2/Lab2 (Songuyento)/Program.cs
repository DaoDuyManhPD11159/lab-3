﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2__Songuyento_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap vao mot so: ");
            int so = int.Parse(Console.ReadLine());
            bool soNT = true;
            if (so < 2)
            {
                soNT = false;
            }
            for (int i = 2; i < so / 2; i++)
            {
                if (so % i == 0)
                {
                    soNT = false;
                    break;
                }
            }
            if (soNT)
            {
                Console.Write($"{so} la so nguyen to.");
            }
            else
            {
                Console.Write($"{so} khong phai so nguyen to.");
            }
            Console.ReadKey();
        }
    }
}
