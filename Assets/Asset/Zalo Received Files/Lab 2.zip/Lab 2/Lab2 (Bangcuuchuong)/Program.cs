﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2__Bangcuuchuong_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\n");
            Console.Write("In bang cuu chuong:\n");
            Console.Write("----------------------------");
            Console.Write("\n\n");

            int num, so_nhan;

            num = 2;

            do
            {

                so_nhan = 1;
                do
                {
                    Console.WriteLine("{0} x {1} = {2}",
                        num, so_nhan, num * so_nhan);
                    so_nhan++;
                }
                while (so_nhan <= 10);

                Console.WriteLine();
                num++;

            } while (num <= 9);

            Console.ReadKey();
        }
    }
}
